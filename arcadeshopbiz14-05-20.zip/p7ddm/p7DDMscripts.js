
/* 
 ================================================
 PVII Drill Down Menu Magic  scripts
 Copyright (c) 2019 Project Seven Development
 www.projectseven.com
 Version: 1.0.6 -build 16
 ================================================
 
 */
var p7DDM = {
	ctl: [],
	once: false,
	clk: false,
	prf: 'none',
	adv: [],
	bodyPush: false,
	defAnim: 1,
	defDuration: 360,
	frameRate: (1000 / 60)
};
function P7_DDMbb(){
}

function P7_DDMaddLoad(){
	if (window.addEventListener) {
		document.addEventListener("DOMContentLoaded", P7_DDMinit, false);
		window.addEventListener("load", P7_DDMinit, false);
		window.addEventListener("unload", P7_DDMbb, false);
	} else if (window.attachEvent) {
		window.attachEvent("onload", P7_DDMinit);
		window.attachEvent("onunload", P7_DDMbb);
	}
}

P7_DDMaddLoad();
function P7_DDMinit(){
	var i, x, cT, j, tB, op, tR, tU, el, an, w;
	if (p7DDM.once) {
		return;
	}
	p7DDM.once = true;
	p7DDM.prf = P7_DDMgetCSSPre();
	cT = P7_DDMgetByAttribute('data-ddm', 'ddm-menu');
	for (j = 0; j < cT.length; j++) {
		p7DDM.ctl.push(cT[j]);
		tB = cT[j];
		op = tB.getAttribute('data-ddm').split(',');
		tB = document.getElementById('p7DDM_' + op[0]);
		tB.ddmOpt = op;
		if (tB.ddmOpt[14] != 1) {
			if (tB.parentNode.nodeName != 'BODY') {
				document.getElementsByTagName('BODY')[0].appendChild(tB);
			}
		} else {
			tB.style.minHeight = tB.ddmOpt[15] + 'px';
		}
		P7_DDMremClass(tB, 'ddm-noscript');
		el = document.getElementById(tB.id.replace('_', 'b_'));
		if (el) {
			P7_DDMremClass(el, 'ddm-noscript');
		}
		p7DDM.ctl[p7DDM.ctl.length] = tB;
		if (p7DDM.prf == 'none') {
			tB.ddmOpt[1] = 0;
			tB.ddmOpt[3] = 0;
		}
		tB.ddmMenuState = 'closed';
		if (tB.ddmOpt[14] != 1) {
			tB.style.zIndex = tB.ddmOpt[6];
			if (el) {
				el.style.zIndex = (tB.ddmOpt[6] - 2);
			}
		}
		tB.ddmDimmer = false;
		if (tB.ddmOpt[5] == 1 && tB.ddmOpt[14] !== 1) {
			el = document.createElement('div');
			el.setAttribute('id', tB.id.replace('_', 'dm_'));
			el.className = 'ddm-dimmer';
			el.style.zIndex = tB.ddmOpt[6] - 1;
			el.ddmMenu = tB;
			document.getElementsByTagName('BODY')[0].appendChild(el);
			if (tB.ddmOpt[13] > 0) {
				P7_DDMsetClass(el, 'ddm-DM-' + tB.ddmOpt[13]);
			}
			el.onclick = function(){
				return P7_DDMtrig(this.ddmMenu.id, 'close');
			};
			tB.ddmDimmer = el;
		}
		if (tB.ddmOpt[11] == 1) {
			P7_DDMsetClass(document.body, 'ddm-body-push');
		}
		an = tB.ddmOpt[1];
		if (an < 2) {
			if ((tB.ddmOpt[7] == 1)) {
				tB.style.right = '-120%';
			} else {
				tB.style.left = '-120%';
			}
		}
		if (tB.ddmOpt[1] == 2 || tB.ddmOpt[1] == 3) {
			x = (tB.offsetWidth + 60) * -1;
			if (tB.ddmOpt[7] == 1) {
				tB.style.marginRight = x + 'px';
			} else {
				tB.style.marginLeft = x + 'px';
			}
			tB.style.opacity = (tB.ddmOpt[1] == 3) ? 0 : 1;
		} else if (tB.ddmOpt[1] == 1) {
			tB.style.opacity = 0;
		}
		tU = tB.getElementsByTagName('UL');
		tB.ddmRootUL = tU[0];
		tB.ddmRootDiv = tU[0].parentNode;
		tB.ddmCurSub = tB.ddmRootDiv;
		tB.ddmPrevSub = tB.ddmRootDiv;
		P7_DDMinitUL(tB, tU[0], 0);
		tR = document.getElementById(tB.id.replace('_', 'tb_'));
		if (tR) {
			tR.ddmMenu = tB;
			tB.ddmTrig = tR;
			tR.onclick = function(){
				return P7_DDMtrig(this.ddmMenu.id);
			};
		}
		tR = document.getElementById(tB.id.replace('_', 'tc_'));
		if (tR) {
			tR.ddmMenu = tB;
			tB.ddmCloseTrig = tR;
			tR.onclick = function(){
				return P7_DDMtrig(this.ddmMenu.id, 'close');
			};
		}
		tR = document.getElementById(tB.id.replace('_', 'ts_'));
		if (tR) {
			tR.ddmMenu = tB;
			tB.ddmTopTrig = tR;
			tR.onclick = function(){
				return P7_DDMtop(this.ddmMenu.id);
			};
		}
		if (!p7DDM.clk) {
			p7DDM.clk = true;
			if (window.addEventListener) {
				document.addEventListener("click", P7_DDMbody, false);
			} else if (window.attachEvent) {
				window.attachEvent("click", P7_DDMbody, false);
			}
		}
		if (tB.ddmOpt[8] == 1) {
			P7_DDMcurrentMark(tB);
		}
		if (tB.ddmOpt[12] == 1) {
			tB.ddmOpenTimer = setTimeout(P7_DDMcreateTMH(tB), 500);
		}
		if (tB.ddmDefLink && tB.ddmDefLink.ddmSTE) {
			P7_DDMclick(tB.ddmDefLink, 1);
		}
	}
}

function P7_DDMcreateTMH(el){
	return function(){
		P7_DDMtrig(el.id, 'open');
	};
}

function P7_DDMinitUL(d, ul, lv){
	var i, x, li, cl, tA, sD, su, tH, wH, nlv, bb, an;
	P7_DDMsetClass(ul, 'ddm-level-' + lv);
	ul.ddmLevel = lv;
	ul.ddmDiv = d;
	sD = ul.parentNode;
	an = d.ddmOpt[3];
	if (lv > 0) {
		if (an < 2) {
			if ((d.ddmOpt[7] == 1)) {
				sD.style.right = '120%';
				sD.style.left = 'auto';
			} else {
				sD.style.left = '-120%';
				sD.style.right = 'auto';
			}
		}
		if (an == 2 || an == 3) {
			x = ((d.ddmOpt[7] == 1)) ? '120' : '-120';
			sD.style[p7DDM.prf + 'transform'] = 'translate3d(' + x + '%, 0, 0)';
			if ((d.ddmOpt[7] == 1)) {
				sD.style.right = '0px';
			} else {
				sD.style.left = '0px';
			}
			sD.style.opacity = (d.ddmOpt[3] == 3) ? 0 : 1;
		} else if (an == 1) {
			sD.style.opacity = 0;
		}
	}
	li = ul.childNodes;
	wH = window.location.href;
	wH = wH.replace(window.location.hash, '');
	for (i = 0; i < li.length; i++) {
		if (li[i].tagName && li[i].tagName == 'LI') {
			li[i].ddmLevel = lv;
			tA = li[i].getElementsByTagName('A');
			if (tA && tA[0]) {
				tA[0].ddmState = 'closed';
				tA[0].ddmDiv = d.id;
				if (/ddm-ste/.test(tA[0].getAttribute('class'))) {
					tH = tA[0].href;
					tH = tH.replace(tA[0].hash, '');
					if (tH == wH) {
						tA[0].ddmSTE = true;
					}
				}
				tA[0].onclick = function(evt){
					return P7_DDMclick(this);
				};
				su = li[i].getElementsByTagName('UL');
				if (su && su[0]) {
					tA[0].ddmSub = su[0].parentNode;
					tA[0].ddmParentSub = ul.parentNode;
					su[0].parentNode.ddmTrigger = tA[0];
					nlv = lv + 1;
					su[0].ddmTrigger = tA[0];
					bb = tA[0].ddmSub.getElementsByClassName('ddm-back');
					if (bb && bb[0]) {
						bb[0].ddmTrig = tA[0];
						bb[0].ddmDiv = d.id;
						bb[0].onclick = function(evt){
							return P7_DDMback(this.ddmDiv);
						};
					}
					P7_DDMinitUL(d, su[0], nlv);
				}
			}
		}
	}
}

function P7_DDMdimmer(tB, ac, dur){
	if (tB.ddmDimmer) {
		if (ac == 'open') {
			if (tB.ddmDimmer.ddmAnimC) {
				clearTimeout(tB.ddmDimmer.ddmAnimC);
			}
			P7_DDMsetClass(tB.ddmDimmer, 'ddm-open');
			tB.ddmDimmer.style[p7DDM.prf + 'transition'] = 'opacity ' + dur + 'ms linear';
			tB.ddmDimmer.style.opacity = 1;
			tB.ddmDimmer.style.top = '0px';
		} else if (ac == 'close') {
			P7_DDMremClass(tB.ddmDimmer, 'ddm-open');
			tB.ddmDimmer.style.opacity = 0;
			tB.ddmDimmer.ddmAnimC = setTimeout(function(){
				tB.ddmDimmer.style.top = '-100%';
			}, dur);
		}
	}
}

function P7_DDMtrig(d, ac, bp){
	var tB, st, bd, dur, an, x, p;
	tB = document.getElementById(d);
	bd = document.body;
	an = tB.ddmOpt[1];
	if (tB) {
		dur = (bp && bp == 1) ? 0 : tB.ddmOpt[2];
		if (an < 1 || bp == 1) {
			dur = 0;
		}
		st = tB.ddmMenuState;
		if ((!ac && st == 'closed') || ac == 'open') {
			P7_DDMsetClass(document.body, 'ddm-active');
			P7_DDMdimmer(tB, 'open', dur);
			P7_DDMsetClass(tB, 'ddm-open');
			tB.ddmMenuState = 'open';
			P7_DDMsetClass(tB.ddmTrig, 'ddm-open');
			if (tB.ddmAnimC) {
				clearTimeout(tB.ddmAnimC);
			}
			if (tB.ddmOpt[11] == 1) {
				P7_DDMpush(tB, 'open', dur);
			}
			if (an == 1) {
				if (tB.ddmOpt[7] == 1) {
					tB.style.right = '0px';
				} else {
					tB.style.left = '0px';
				}
				tB.style[p7DDM.prf + 'transition'] = 'opacity ' + dur + 'ms linear';
				tB.style.opacity = 1;
			} else if (an == 2 || an == 3) {
				tB.style[p7DDM.prf + 'transition'] = 'margin-left ' + dur + 'ms ease-in-out, opacity ' + dur + 'ms linear';
				if (tB.ddmOpt[7] == 1) {
					tB.style[p7DDM.prf + 'transition'] = 'margin-right ' + dur + 'ms ease-in-out, opacity ' + dur + 'ms linear';
					tB.style.marginRight = '0px';
				} else {
					tB.style[p7DDM.prf + 'transition'] = 'margin-left ' + dur + 'ms ease-in-out, opacity ' + dur + 'ms linear';
					tB.style.marginLeft = '0px';
				}
				tB.style.opacity = 1;
			} else {
				if (tB.ddmOpt[7] == 1) {
					tB.style.right = '0px';
				} else {
					tB.style.left = '0px';
				}
			}
		} else if ((!ac && st == 'open') || ac == 'close') {
			P7_DDMremClass(tB, 'ddm-open');
			tB.ddmMenuState = 'closed';
			if (tB.ddmOpt[11] != 1) {
				P7_DDMclearActive();
			}
			P7_DDMremClass(tB.ddmTrig, 'ddm-open');
			if (tB.ddmOpt[11] == 1) {
				P7_DDMpush(tB, 'close', dur);
			}
			P7_DDMdimmer(tB, 'close', dur);
			if (an == 1) {
				tB.style.opacity = 0;
				tB.ddmAnimC = setTimeout(function(){
					if (tB.ddmOpt[7] == 1) {
						tB.style.right = '120%';
					} else {
						tB.style.left = '-120%';
					}
				}, dur);
			} else if (an == 2 || an == 3) {
				p = (an == 3) ? 0 : 1;
				x = (tB.offsetWidth + 60) * -1;
				if (tB.ddmOpt[7] == 1) {
					tB.style.marginRight = x + 'px';
				} else {
					tB.style.marginLeft = x + 'px';
				}
				tB.style.opacity = p;
			} else {
				if (tB.ddmOpt[7] == 1) {
					tB.style.right = '120%';
				} else {
					tB.style.left = '-120%';
				}
			}
		}
	}
	return false;
}

function P7_DDMpush(tB, ac, dur){
	var x, el = document.body;
	if (el.ddmAnimC) {
		clearTimeout(el.ddmAnimC);
	}
	if (ac == 'open') {
		x = tB.offsetWidth;
		if (tB.ddmOpt[7] == 1) {
			x = x * -1;
		}
		el.style.width = '100%';
		el.style[p7DDM.prf + 'transition'] = 'left ' + dur + 'ms ease-in-out';
		el.style.left = x + 'px';
	} else if (ac == 'close') {
		el.style.left = '0px';
		el.ddmAnimC = setTimeout(function(){
			el.style.width = 'auto';
			P7_DDMclearActive();
		}, dur);
	}
}

function P7_DDMclearActive(){
	var i, tB, m = false;
	for (i = 0; i < p7DDM.ctl.length; i++) {
		tB = p7DDM.ctl[i];
		if (tB.ddmState == 'open') {
			m = true;
		}
	}
	if (!m) {
		P7_DDMremClass(document.body, 'ddm-active');
	}
}

function P7_DDMbody(evt){
	evt = (evt) ? evt : event;
	var m = true, pp = (evt.fromElement) ? evt.fromElement : evt.target;
	while (pp) {
		if (pp.ddmTrig) {
			m = false;
			break;
		}
		if (pp && pp.id && typeof(pp.id) == 'string' && pp.id.indexOf('p7DDM') === 0) {
			m = false;
			break;
		}
		if (pp && pp.tagName && (pp.tagName == 'BODY' || pp.tagName == 'HTML')) {
			break;
		}
		pp = pp.parentNode;
	}
	if (m) {
		P7_DDMshutAll();
	}
}

function P7_DDMclick(a, bp){
	var wH, tB, m = false;
	wH = window.location.href;
	if (a.href != wH && a.href != wH + '#') {
		if (a.href.toLowerCase().indexOf('javascript:') == -1) {
			m = true;
		}
	}
	if (m && a.ddmSub && a.ddmState == 'closed') {
		m = false;
	}
	tB = document.getElementById(a.ddmDiv);
	if (a.ddmSTE) {
		P7_DDMste(a);
		m = false;
		if (bp != 1) {
			P7_DDMtrig(a.ddmDiv, 'close');
		}
	} else {
		if (a.ddmState == 'closed') {
			P7_DDMopen(a);
		} else {
			P7_DDMclose(a);
		}
	}
	return m;
}

function P7_DDMopen(a, bp){
	var tB, sD, op, an, x, dur;
	if (a.ddmState == 'open') {
		return;
	}
	tB = document.getElementById(a.ddmDiv);
	if (a.ddmSub) {
		sD = a.ddmSub;
		an = tB.ddmOpt[3];
		dur = (bp && bp == 1) ? 0 : tB.ddmOpt[4];
		if (an < 1 || bp == 1) {
			dur = 0;
		}
		a.ddmState = 'open';
		tB.ddmCurSub = sD;
		P7_DDMremClass(a.ddmParentSub, 'ddm-flow');
		P7_DDMsetClass(a.ddmSub, 'ddm-flow');
		P7_DDMsetClass(sD, 'ddm-open');
		if (an == 1) {
			if (sD.ddmAnimC) {
				clearTimeout(sD.ddmAnimC);
			}
			if (tB.ddmOpt[7] == 1) {
				sD.style.right = '0px';
			} else {
				sD.style.left = '0px';
			}
			sD.style[p7DDM.prf + 'transition'] = 'opacity ' + dur + 'ms linear';
			sD.style.opacity = 1;
		} else if (an == 2 || an == 3) {
			x = 0;
			sD.style[p7DDM.prf + 'transition'] = 'transform ' + dur + 'ms ease-in-out, opacity ' + dur + 'ms linear';
			sD.style[p7DDM.prf + 'transform'] = 'translate3d(' + x + '%, 0, 0)';
			sD.style.opacity = 1;
		} else {
			if (tB.ddmOpt[7] == 1) {
				sD.style.right = '0px';
			} else {
				sD.style.left = '0px';
			}
		}
	}
}

function P7_DDMclose(a, bp){
	var tB, sD, op, an, x, dur, p;
	if (a.ddmState == 'closed') {
		return;
	}
	tB = document.getElementById(a.ddmDiv);
	if (a.ddmSub) {
		sD = a.ddmSub;
		dur = (bp && bp == 1) ? 0 : tB.ddmOpt[4];
		an = tB.ddmOpt[3];
		if (an < 1 || bp == 1) {
			dur = 0;
		}
		a.ddmState = 'closed';
		tB.ddmCurSub = a.ddmParentSub;
		P7_DDMremClass(sD, 'ddm-flow');
		P7_DDMsetClass(a.ddmParentSub, 'ddm-flow');
		P7_DDMremClass(sD, 'ddm-open');
		if (an == 1) {
			if (sD.ddmAnimC) {
				clearTimeout(sD.ddmAnimC);
			}
			sD.style[p7DDM.prf + 'transition'] = 'opacity ' + dur + 'ms linear';
			sD.style.opacity = 0;
			sD.ddmAnimC = setTimeout(function(){
				if (tB.ddmOpt[7] == 1) {
					sD.style.right = '100%';
				} else {
					sD.style.left = '-100%';
				}
			}, dur);
		} else if (an == 2 || an == 3) {
			x = (tB.ddmOpt[7] == 1) ? '100' : '-100';
			p = (an == 3) ? 0 : 1;
			sD.style[p7DDM.prf + 'transition'] = 'transform ' + dur + 'ms ease-in-out, opacity ' + dur + 'ms linear';
			sD.style[p7DDM.prf + 'transform'] = 'translate3d(' + x + '%, 0, 0)';
			sD.style.opacity = p;
		} else {
			if (tB.ddmOpt[7] == 1) {
				sD.style.right = '100%';
			} else {
				sD.style.left = '-100%';
			}
		}
	}
}

function P7_DDMback(d){
	var tB, sD, a;
	tB = document.getElementById(d);
	if (tB) {
		sD = tB.ddmCurSub;
		a = sD.ddmTrigger;
		if (a) {
			P7_DDMclose(a);
		}
	}
	return false;
}

function P7_DDMtop(d){
	var tB, pp, a;
	tB = document.getElementById(d);
	if (tB) {
		pp = tB.ddmCurSub;
		while (pp) {
			if (pp.ddmTrigger && !pp.ddmDiv) {
				P7_DDMclose(pp.ddmTrigger);
			}
			if (pp.id && pp.id.indexOf('p7DDM_') > -1) {
				break;
			}
			pp = pp.parentNode;
		}
	}
	return false;
}

function P7_DDMshutAll(bp){
	var i, tB;
	for (i = 0; i < p7DDM.ctl.length; i++) {
		tB = p7DDM.ctl[i];
		if (tB && (!bp || bp != tB.id)) {
			P7_DDMtrig(tB.id, 'close');
		}
	}
}

function P7_DDMgetTime(st){
	var d = new Date();
	return d.getTime() - st;
}

function P7_DDManim(tp, t, b, c, d){
	if (tp == 'quad') {
		return -c * (t /= d) * (t - 2) + b;
	} else if (tp == 'cubic') {
		return c * ((t = t / d - 1) * t * t + 1) + b;
	} else {
		return (c * (t / d)) + b;
	}
}

function P7_DDMste(a){
	var el, h, tb, st, t, tf, tB, bD, sb, se;
	bD = document.body;
	h = a.hash;
	if (!h || h === '') {
		return false;
	} else {
		h = h.replace('#', '');
	}
	el = document.getElementById(h);
	if (!el) {
		return false;
	}
	bD.p7AnimRunning = false;
	sb = document.body.scrollTop;
	se = document.documentElement.scrollTop;
	if (sb.p7STEanim) {
		sb.p7AnimRunning = false;
		clearInterval(sb.p7STEanim);
	}
	if (se.p7STEanim) {
		se.p7AnimRunning = false;
		clearInterval(se.p7STEanim);
	}
	st = sb;
	if (se > sb) {
		st = se;
	}
	t = st + el.getBoundingClientRect().top + 1;
	tf = parseInt(a.getAttribute('data-top-offset'), 10);
	if (tf && tf !== '') {
		t -= tf;
	}
	tf = a.getAttribute('data-top-offset-id');
	if (tf && tf !== '') {
		tb = document.getElementById(tf);
		if (tb) {
			t -= tb.offsetHeight;
		}
	}
	if (p7DDM.defAnim == 1) {
		bD.p7animType = 'quad';
		bD.p7animStartVal = st;
		bD.p7animCurrentVal = bD.p7animStartVal;
		bD.p7animFinishVal = t;
		bD.p7animStartTime = P7_DDMgetTime(0);
		bD.p7animDuration = p7DDM.defDuration;
		if (!bD.p7AnimRunning) {
			bD.p7AnimRunning = true;
			bD.p7STEanim = setInterval(function(){
				P7_DDMsteA(bD);
			}, p7DDM.frameRate);
		}
	} else {
		bD.body.scrollTop = t;
		document.documentElement.scrollTop = t;
		if (typeof(P7_STTrsz) == 'function') {
			P7_STTrsz();
		}
	}
	return false;
}

function P7_DDMsteA(el){
	var et, nv, m = false;
	et = P7_DDMgetTime(el.p7animStartTime);
	if (et >= el.p7animDuration) {
		et = el.p7animDuration;
		m = true;
	}
	if (el.p7animCurrentVal != el.p7animFinishVal) {
		nv = P7_DDManim(el.p7animType, et, el.p7animStartVal, el.p7animFinishVal - el.p7animStartVal, el.p7animDuration);
		el.p7animCurrentVal = nv;
		el.scrollTop = nv;
		document.documentElement.scrollTop = nv;
	}
	if (m) {
		el.p7AnimRunning = false;
		clearInterval(el.p7STEanim);
		if (typeof(P7_STTrsz) == 'function') {
			P7_STTrsz();
		}
	}
}

function P7_DDMmark(){
	p7DDM.adv.push(arguments);
}

function P7_DDMcurrentMark(el){
	var j, i, wH, cm = false, mt = ['', 1, '', ''], op, r1, k, kk, tA, aU, pp, a, im, x, mk;
	wH = window.location.href;
	if (el.ddmOpt[9] != 1) {
		wH = wH.replace(window.location.search, '');
	}
	if (wH.charAt(wH.length - 1) == '#') {
		wH = wH.substring(0, wH.length - 1);
	}
	for (k = 0; k < p7DDM.adv.length; k++) {
		if (p7DDM.adv[k][0] && p7DDM.adv[k][0] == el.id) {
			mt = p7DDM.adv[k];
			cm = true;
			break;
		}
	}
	op = mt[1];
	if (op < 1) {
		return;
	}
	r1 = /index\.[\S]*/i;
	k = -1;
	kk = -1;
	tA = el.ddmRootUL.getElementsByTagName('A');
	for (j = 0; j < tA.length; j++) {
		aU = tA[j].href.replace(r1, '');
		if (op > 0) {
			if (tA[j].href == wH || aU == wH) {
				k = j;
				kk = -1;
			}
		}
		if (op == 2) {
			if (tA[j].firstChild) {
				if (tA[j].firstChild.nodeValue == mt[2]) {
					kk = j;
				}
			}
		}
		if (op == 3 && tA[j].href.indexOf(mt[2]) > -1) {
			kk = j;
		}
		if (op == 4) {
			for (x = 2; x < mt.length; x += 2) {
				if (wH.indexOf(mt[x]) > -1) {
					if (tA[j].firstChild && tA[j].firstChild.nodeValue) {
						if (tA[j].firstChild.nodeValue == mt[x + 1]) {
							kk = j;
						}
					}
				}
			}
		}
	}
	k = (kk > k) ? kk : k;
	if (k > -1) {
		el.ddmDefLink = tA[k];
		pp = tA[k].parentNode;
		mk = [];
		while (pp) {
			if (pp.tagName && pp.tagName == 'LI') {
				P7_DDMsetClass(pp, 'current-mark');
				a = pp.getElementsByTagName('A');
				if (a && a[0]) {
					P7_DDMsetClass(a[0], 'current-mark');
				}
				if (el.ddmOpt[10] == 1 && a[0].ddmSub) {
					mk.push(a[0]);
				}
			} else {
				if (pp == el.ddmRootUL) {
					break;
				}
			}
			pp = pp.parentNode;
		}
		if (mk && mk.length > 0) {
			for (i = mk.length - 1; i > -1; i--) {
				P7_DDMopen(mk[i], 1);
			}
		}
	}
}

function P7_DDMgetByAttribute(att, cls){
	var i, nL = [], aT, rS = [], cl, el;
	if (document.querySelectorAll) {
		nL = document.querySelectorAll('*[' + att + ']');
	} else {
		if (typeof(document.getElementsByClassName) != 'function') {
			aT = document.getElementsByTagName('*');
			for (i = 0; i < aT.length; i++) {
				cl = aT[i].className;
				if (cl && cl.indexOf(cls) > -1) {
					rS[rS.length] = aT[i];
				}
			}
		} else {
			rS = document.getElementsByClassName(cls);
		}
		for (i = 0; i < rS.length; i++) {
			if (rS[i].getAttribute(att)) {
				nL[nL.length] = rS[i];
			}
		}
	}
	return nL;
}

function P7_DDMsetClass(ob, cl){
	if (ob) {
		var cc, nc, r = /\s+/g;
		cc = ob.className;
		nc = cl;
		if (cc && cc.length > 0) {
			if (cc.indexOf(cl) == -1) {
				nc = cc + ' ' + cl;
			} else {
				nc = cc;
			}
		}
		nc = nc.replace(r, ' ');
		ob.className = nc;
	}
}

function P7_DDMremClass(ob, cl){
	if (ob) {
		var cc, nc;
		cc = ob.className;
		cl = cl.replace('-', '\-');
		var re = new RegExp('\\b' + cl + '\\b');
		if (re.test(cc)) {
			nc = cc.replace(re, '');
			nc = nc.replace(/\s+/g, ' ');
			nc = nc.replace(/\s$/, '');
			nc = nc.replace(/^\s/, '');
			if (nc === '' || nc === ' ') {
				ob.removeAttribute('class');
			} else {
				ob.className = nc;
			}
		}
	}
}

function P7_DDMgetCSSPre(){
	var i, dV, pre = ['animationDuration', 'WebkitAnimationDuration'];
	var c = 'none', cssPre = ['', '-webkit-'];
	dV = document.createElement('div');
	for (i = 0; i < pre.length; i++) {
		if (dV.style[pre[i]] !== undefined) {
			c = cssPre[i];
			break;
		}
	}
	return c;
}

function P7_DDMgetStyle(el, s){
	if (el.currentStyle) {
		s = el.currentStyle[s];
	} else if (document.defaultView && document.defaultView.getComputedStyle) {
		s = document.defaultView.getComputedStyle(el, "")[s];
	} else {
		s = el.style[s];
	}
	return s;
}
